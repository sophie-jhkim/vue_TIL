new Vue({
    el:'#section1',
    data :{
        title: '뷰 생성과 탬플릿',
        subject:'v-if-else 다중 if문',
        t1: true, //클래스 속성 적용
        t2: true,
        score: 73
        
    },
    methods:{ 



    }
});

